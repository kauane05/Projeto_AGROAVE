# Projeto_AGROAVE

> Integrantes do grupo 

* Kauane | Cadastrar Cliente- Pessoa Física
* Raylayne | Cadastrar Fornecedor
* Tainara  | Cadastrar Estoque (Produção)
* Sabrina | Controlar acesso ao perfil do funcionário
* Nathália | Consultar Entrega
